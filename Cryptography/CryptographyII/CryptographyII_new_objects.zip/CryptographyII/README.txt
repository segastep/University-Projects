All source code and reports are under CryptographyII/src

Answers to the first part of the coursework are located under src/ExerciseIIone
Utils class provides the method definitions for all necessary computations.
The answer to question 3 from part one of the coursework is located under src/ExerciseIIone
with filename Question3

Source code for part 2 of the coursework is located under src/ExerciseIItwo
DHutils is a class which contains all methods needed for key exchange
Msg and Side classes are just wrappers.
Answers to questions 3, 4a are located under src/ExerceseIItwo

To run the code execute the runner class in each package, for partII of the coursework,
attack and transactions transcripts will be created.

For second part of the CW:
Ordering of events, and communication establishment logic is presented in the runner classes.
methods you are interested in are keyExhange() and keyExchangeAttack()

I apologize for the messy structure.

Each run will generate two files:
attack-> followed by the current date and time - this is a transcript for the attack
transcript->followed by the current date and time - this is a transcript of the key exchange part of the coursework

All computation logic in uder the DHutil classes.
